var ptx_lunr_search_style = "textbook";
var ptx_lunr_docs = [
{
  "id": "root-1-1",
  "level": "1",
  "url": "root-1-1.html",
  "type": "Article",
  "number": "",
  "title": "",
  "body": "  Math 221 Tangent Line Worksheet     Show how to include an image using Prefigure code.    Show displayed and alligned math as well as some minor math typesetting issues that come from xml syntax (see the code for details).      In this activity students are asked to decide when to switch the tangent line approximation they use to approximate square roots.    Set-up  Recall from class that we can approximate square roots of numbers that aren't perfect squares using the tangent line approximation near some number  where .  For instance, to approximate we decided to use the tangent line approximation at the nearest perfect square, which is given by  Thus, we can estimate .  Now, what if there isn't a \"nearest\" perfect square? For instance, which tangent line should we use to approximate ( is exactly halfway between and )? The following exercise will help us figure out the answer.     The graph of , along with its tangent lines at and , is given by .   The graph of and its tangent line approximations at and .      a=4  b=9  f(x) = x^(0.5)          (4,2)    f(x) = \\sqrt{x}         (9,3)            Use to give intervals of -values on which and give more accurate estimates of . That is, find some -value, , such that whenever and whenever .      Use algebra to justify your answer above.      Interactive Remarks    Note the issues in the code where Latex syntax conflicted with xml. There are a few instances when these happen.      Prefigure is really more intuitive to use than Tikz and generates more accessible images. Full documentation is available at and a very convenient tool for testing your figures is available at .      "
},
{
  "id": "root-1-1-1-2",
  "level": "2",
  "url": "root-1-1.html#root-1-1-1-2",
  "type": "Objectives",
  "number": "",
  "title": "",
  "body": "   Show how to include an image using Prefigure code.    Show displayed and alligned math as well as some minor math typesetting issues that come from xml syntax (see the code for details).    "
},
{
  "id": "root-1-1-1-5",
  "level": "2",
  "url": "root-1-1.html#root-1-1-1-5",
  "type": "Worksheet Exercise",
  "number": "1",
  "title": "",
  "body": "  The graph of , along with its tangent lines at and , is given by .   The graph of and its tangent line approximations at and .      a=4  b=9  f(x) = x^(0.5)          (4,2)    f(x) = \\sqrt{x}         (9,3)            Use to give intervals of -values on which and give more accurate estimates of . That is, find some -value, , such that whenever and whenever .      Use algebra to justify your answer above.    "
},
{
  "id": "prefigure-math-remarks-2",
  "level": "2",
  "url": "root-1-1.html#prefigure-math-remarks-2",
  "type": "Remark",
  "number": "2",
  "title": "",
  "body": "  Note the issues in the code where Latex syntax conflicted with xml. There are a few instances when these happen.   "
},
{
  "id": "prefigure-math-remarks-3",
  "level": "2",
  "url": "root-1-1.html#prefigure-math-remarks-3",
  "type": "Remark",
  "number": "3",
  "title": "",
  "body": "  Prefigure is really more intuitive to use than Tikz and generates more accessible images. Full documentation is available at and a very convenient tool for testing your figures is available at .   "
}
]

var ptx_lunr_idx = lunr(function () {
  this.ref('id')
  this.field('title')
  this.field('body')
  this.metadataWhitelist = ['position']

  ptx_lunr_docs.forEach(function (doc) {
    this.add(doc)
  }, this)
})
